$(document).ready(function () {
  $('#id_product').change(updateVersionSelectFromProduct)
})
