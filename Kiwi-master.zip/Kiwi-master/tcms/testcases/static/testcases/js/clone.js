$(document).ready(function () {
  $('.bootstrap-switch').bootstrapSwitch()
})
