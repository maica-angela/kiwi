---
name: Bug report
about: Create a report to help us improve Kiwi TCMS
title: ''
labels: ''
assignees: ''

---

HINT: try to reproduce bugs and errors at https://public.tenant.kiwitcms.org!
This is always running the latest version and will automatically submit
traceback and debugging information to us!


### Description of problem


### Version or commit hash (if applicable)


### Steps to Reproduce

1.
2.
3.

### Actual results


### Expected results


### Additional info (Python traceback, logs, etc.)
