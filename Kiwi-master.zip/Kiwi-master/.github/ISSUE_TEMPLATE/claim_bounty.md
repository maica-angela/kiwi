---
name: Claim a completed bounty
about: validate your identity before collecting bounty for complated tasks
title: ''
labels: ''
assignees: 'atodorov'

---

**URL to expense submitted via Open Collective**
