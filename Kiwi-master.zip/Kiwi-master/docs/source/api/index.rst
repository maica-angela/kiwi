.. _api:

Kiwi TCMS Python API client
===========================

Client side configuration is documented at https://tcms-api.readthedocs.io.
Server side RPC methods are documented in :mod:`tcms.rpc.api`.
