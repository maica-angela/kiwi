tcms.core.management.commands package
=====================================

.. automodule:: tcms.core.management.commands
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   tcms.core.management.commands.init_db
   tcms.core.management.commands.initial_setup
   tcms.core.management.commands.migrations_order
   tcms.core.management.commands.refresh_permissions
   tcms.core.management.commands.set_domain
   tcms.core.management.commands.upgrade
