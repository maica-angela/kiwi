tcms.issuetracker.azure\_boards module
======================================

.. automodule:: tcms.issuetracker.azure_boards
   :members:
   :undoc-members:
   :show-inheritance:
