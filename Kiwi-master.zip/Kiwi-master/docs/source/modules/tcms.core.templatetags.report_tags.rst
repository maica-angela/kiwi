tcms.core.templatetags.report\_tags module
==========================================

.. automodule:: tcms.core.templatetags.report_tags
   :members:
   :undoc-members:
   :show-inheritance:
