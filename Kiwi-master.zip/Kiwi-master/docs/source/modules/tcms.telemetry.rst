tcms.telemetry package
======================

.. automodule:: tcms.telemetry
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   tcms.telemetry.api
   tcms.telemetry.views
