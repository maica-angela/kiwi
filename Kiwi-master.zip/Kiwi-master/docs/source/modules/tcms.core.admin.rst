tcms.core.admin module
======================

.. automodule:: tcms.core.admin
   :members:
   :undoc-members:
   :show-inheritance:
