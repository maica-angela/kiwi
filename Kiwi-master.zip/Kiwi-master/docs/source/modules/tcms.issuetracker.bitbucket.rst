tcms.issuetracker.bitbucket module
==================================

.. automodule:: tcms.issuetracker.bitbucket
   :members:
   :undoc-members:
   :show-inheritance:
