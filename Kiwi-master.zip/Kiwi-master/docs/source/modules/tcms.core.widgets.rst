tcms.core.widgets module
========================

.. automodule:: tcms.core.widgets
   :members:
   :undoc-members:
   :show-inheritance:
