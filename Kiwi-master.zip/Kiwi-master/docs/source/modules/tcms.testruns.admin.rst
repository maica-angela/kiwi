tcms.testruns.admin module
==========================

.. automodule:: tcms.testruns.admin
   :members:
   :undoc-members:
   :show-inheritance:
