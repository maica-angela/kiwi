tcms.core.models.abstract module
================================

.. automodule:: tcms.core.models.abstract
   :members:
   :undoc-members:
   :show-inheritance:
