tcms.rpc.api.plantype module
============================

.. automodule:: tcms.rpc.api.plantype
   :members:
   :undoc-members:
   :show-inheritance:
