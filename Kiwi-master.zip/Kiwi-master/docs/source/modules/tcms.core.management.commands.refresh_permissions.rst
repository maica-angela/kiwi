tcms.core.management.commands.refresh\_permissions module
=========================================================

.. automodule:: tcms.core.management.commands.refresh_permissions
   :members:
   :undoc-members:
   :show-inheritance:
