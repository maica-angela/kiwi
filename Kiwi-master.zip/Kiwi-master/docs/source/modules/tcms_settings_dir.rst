tcms\_settings\_dir package
===========================

.. automodule:: tcms_settings_dir
   :members:
   :undoc-members:
   :show-inheritance:
