tcms.issuetracker.jira\_integration module
==========================================

.. automodule:: tcms.issuetracker.jira_integration
   :members:
   :undoc-members:
   :show-inheritance:
