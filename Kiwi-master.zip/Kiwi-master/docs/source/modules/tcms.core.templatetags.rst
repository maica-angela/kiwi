tcms.core.templatetags package
==============================

.. automodule:: tcms.core.templatetags
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   tcms.core.templatetags.extra_filters
   tcms.core.templatetags.report_tags
