tcms.bugs.admin module
======================

.. automodule:: tcms.bugs.admin
   :members:
   :undoc-members:
   :show-inheritance:
