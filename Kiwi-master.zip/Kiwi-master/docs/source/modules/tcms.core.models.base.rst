tcms.core.models.base module
============================

.. automodule:: tcms.core.models.base
   :members:
   :undoc-members:
   :show-inheritance:
