tcms.core.management.commands.initial\_setup module
===================================================

.. automodule:: tcms.core.management.commands.initial_setup
   :members:
   :undoc-members:
   :show-inheritance:
